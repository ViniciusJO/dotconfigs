require('colorizer').setup()
